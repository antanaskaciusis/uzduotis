# Užduotis realizuoti kodą kuris apskaičiuotų komisinį mokestį.
## Paleidimas

### Skripto
php script.php testData.csv

Kodas atitinka PSR-1 ir PSR-2 bei PSR-4 standartus.



